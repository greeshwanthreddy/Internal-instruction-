"""Unit tests for Question Generator"""
import pytest
from src.question_generator import QuestionGenerator
from config.settings import settings


def test_get_initial_question():
    """Test getting initial question"""
    generator = QuestionGenerator()
    question = generator.get_initial_question()
    
    assert question is not None
    assert len(question) > 0
    assert "whom" in question.lower() or "who" in question.lower()


def test_should_continue_min_questions():
    """Test should continue when below minimum questions"""
    generator = QuestionGenerator()
    
    # Should continue if below minimum
    assert generator.should_continue(5, 0.5) is True
    assert generator.should_continue(settings.min_questions - 1, 0.9) is True


def test_should_continue_max_questions():
    """Test should stop at max questions"""
    generator = QuestionGenerator()
    
    # Should stop at max questions
    assert generator.should_continue(settings.max_questions, 0.5) is False
    assert generator.should_continue(settings.max_questions + 1, 0.5) is False


def test_should_continue_completeness():
    """Test should stop when sufficiently complete"""
    generator = QuestionGenerator()
    
    # Should stop if >80% complete and above min questions
    assert generator.should_continue(settings.min_questions, 0.85) is False
    assert generator.should_continue(settings.min_questions + 2, 0.9) is False
    
    # Should continue if not complete enough
    assert generator.should_continue(settings.min_questions, 0.7) is True
