"""Unit tests for AI Client"""
import pytest
from src.ai_client import AIClient, AIClientError
from config.settings import settings


@pytest.mark.asyncio
async def test_get_initial_question():
    """Test getting initial question"""
    client = AIClient()
    question = client.get_initial_question()
    
    assert question is not None
    assert len(question) > 0
    assert "whom" in question.lower() or "who" in question.lower()


@pytest.mark.asyncio
async def test_generate_question_no_api_key():
    """Test that missing API key raises error"""
    # Temporarily clear API key
    original_key = settings.deepseek_api_key
    settings.deepseek_api_key = ""
    
    client = AIClient()
    
    with pytest.raises(AIClientError, match="API key not configured"):
        await client.generate_question([], {})
    
    # Restore API key
    settings.deepseek_api_key = original_key


def test_ai_client_initialization():
    """Test AI client initialization"""
    client = AIClient()
    
    assert client.model == settings.model_name
    assert client.temperature == settings.temperature
    assert client.max_tokens == settings.max_tokens
    assert client.timeout == 30.0
    assert client.max_retries == 3
