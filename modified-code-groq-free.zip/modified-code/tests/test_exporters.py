"""Unit tests for Exporters"""
import pytest
import json
from src.exporters import Exporter


def test_export_json_prompt():
    """Test exporting JSON prompt"""
    exporter = Exporter()
    
    prompt = {
        "metadata": {"version": "1.0"},
        "target_user": {"role": "Sales agent"}
    }
    
    result = exporter.export_json_prompt(prompt)
    
    assert isinstance(result, str)
    # Should be valid JSON
    parsed = json.loads(result)
    assert parsed["metadata"]["version"] == "1.0"
    assert parsed["target_user"]["role"] == "Sales agent"


def test_export_conversation_history():
    """Test exporting conversation history"""
    exporter = Exporter()
    
    qa_history = [
        {"question": "Q1?", "answer": "A1"},
        {"question": "Q2?", "answer": "A2"}
    ]
    
    result = exporter.export_conversation_history(qa_history)
    
    assert isinstance(result, str)
    parsed = json.loads(result)
    assert "exported_at" in parsed
    assert "total_questions" in parsed
    assert parsed["total_questions"] == 2
    assert "conversation" in parsed
    assert len(parsed["conversation"]) == 2


def test_export_combined():
    """Test exporting combined data"""
    exporter = Exporter()
    
    prompt = {"metadata": {"version": "1.0"}}
    qa_history = [{"question": "Q1?", "answer": "A1"}]
    
    result = exporter.export_combined(prompt, qa_history)
    
    assert isinstance(result, str)
    parsed = json.loads(result)
    assert "exported_at" in parsed
    assert "prompt" in parsed
    assert "conversation_history" in parsed
    assert len(parsed["conversation_history"]) == 1


def test_get_filename():
    """Test filename generation"""
    exporter = Exporter()
    
    prompt_filename = exporter.get_filename("prompt")
    assert "prompt_output_" in prompt_filename
    assert prompt_filename.endswith(".json")
    
    history_filename = exporter.get_filename("history")
    assert "conversation_history_" in history_filename
    assert history_filename.endswith(".json")
    
    combined_filename = exporter.get_filename("combined")
    assert "complete_export_" in combined_filename
    assert combined_filename.endswith(".json")
