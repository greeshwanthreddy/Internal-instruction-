"""Unit tests for Prompt Builder"""
import pytest
from src.prompt_builder import PromptBuilder


def test_prompt_builder_initialization():
    """Test prompt builder initialization"""
    builder = PromptBuilder()
    prompt = builder.get_current_prompt()
    
    assert "metadata" in prompt
    assert "target_user" in prompt
    assert "requirements" in prompt
    assert "context" in prompt
    assert "conversation_history" in prompt
    assert prompt["metadata"]["total_questions"] == 0


def test_update_prompt():
    """Test updating prompt with Q&A pair"""
    builder = PromptBuilder()
    
    qa_pair = {
        "question": "For whom are you building this?",
        "answer": "Sales agent for healthcare"
    }
    
    builder.update_prompt(qa_pair)
    prompt = builder.get_current_prompt()
    
    assert len(prompt["conversation_history"]) == 1
    assert prompt["metadata"]["total_questions"] == 1
    assert prompt["conversation_history"][0]["question"] == qa_pair["question"]
    assert prompt["conversation_history"][0]["answer"] == qa_pair["answer"]


def test_categorize_target_user():
    """Test categorization of target user"""
    builder = PromptBuilder()
    
    qa_pair = {
        "question": "For whom are you building this?",
        "answer": "Sales agent"
    }
    
    builder.update_prompt(qa_pair)
    prompt = builder.get_current_prompt()
    
    assert "role" in prompt["target_user"]
    assert prompt["target_user"]["role"] == "Sales agent"


def test_categorize_industry():
    """Test categorization of industry"""
    builder = PromptBuilder()
    
    qa_pair = {
        "question": "What industry does this target?",
        "answer": "Healthcare"
    }
    
    builder.update_prompt(qa_pair)
    prompt = builder.get_current_prompt()
    
    assert "industry" in prompt["target_user"]
    assert prompt["target_user"]["industry"] == "Healthcare"


def test_calculate_completeness():
    """Test completeness calculation"""
    builder = PromptBuilder()
    
    # Initially should be 0
    assert builder.calculate_completeness() == 0.0
    
    # Add target user role
    builder.update_prompt({
        "question": "For whom?",
        "answer": "Sales agent"
    })
    
    completeness = builder.calculate_completeness()
    assert completeness > 0.0
    assert completeness <= 1.0


def test_finalize_prompt():
    """Test finalizing prompt"""
    builder = PromptBuilder()
    
    builder.update_prompt({
        "question": "For whom?",
        "answer": "Sales agent"
    })
    
    final_prompt = builder.finalize_prompt()
    
    assert "finalized_at" in final_prompt["metadata"]
    assert "completeness" in final_prompt["metadata"]


def test_reset():
    """Test resetting prompt"""
    builder = PromptBuilder()
    
    builder.update_prompt({
        "question": "Test?",
        "answer": "Test answer"
    })
    
    assert len(builder.get_current_prompt()["conversation_history"]) == 1
    
    builder.reset()
    
    assert len(builder.get_current_prompt()["conversation_history"]) == 0
    assert builder.get_current_prompt()["metadata"]["total_questions"] == 0
