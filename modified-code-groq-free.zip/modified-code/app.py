"""AI-Powered Prompt Builder - Main Streamlit Application"""
import streamlit as st
import asyncio
import json
from src.session_manager import SessionManager
from src.question_generator import QuestionGenerator
from src.exporters import Exporter
from utils.validators import validate_answer
from utils.formatters import format_json_preview, format_progress_text, format_qa_display
from config.settings import settings


# Page configuration
st.set_page_config(
    page_title="AI Prompt Builder",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        font-size: 1.2rem;
        color: #666;
        text-align: center;
        margin-bottom: 2rem;
    }
    .question-box {
        background-color: #f0f8ff;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid #1f77b4;
        margin: 1rem 0;
    }
    .qa-history {
        background-color: #f9f9f9;
        padding: 1rem;
        border-radius: 8px;
        margin: 0.5rem 0;
    }
    .progress-text {
        font-size: 1.1rem;
        font-weight: 600;
        color: #1f77b4;
    }
    .stButton>button {
        width: 100%;
    }
</style>
""", unsafe_allow_html=True)


def main():
    """Main application logic"""
    
    # Initialize session
    SessionManager.initialize_session()
    
    # Header
    st.markdown('<div class="main-header">🤖 AI Prompt Builder</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">Build your perfect AI prompt through interactive Q&A</div>', unsafe_allow_html=True)
    
    # Sidebar - Configuration and Info
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # API Status
        api_key = settings.groq_api_key
        
        if api_key:
            st.success(f"✅ Groq API Key Configured")
            st.info(f"Model: {settings.model_name} (Free - No payment needed!)")
        else:
            st.error(f"❌ Groq API Key Not Configured")
            st.info(f"Please set GROQ_API_KEY in your .env file")
            st.info("🎉 Get your free Groq API key at: https://console.groq.com/keys")
            st.stop()
        
        st.divider()
        
        # Session Info
        st.header("📊 Session Info")
        st.metric("Questions Asked", st.session_state.question_count)
        st.metric("Completeness", f"{int(SessionManager.get_completeness() * 100)}%")
        
        st.divider()
        
        # Reset Button
        if st.button("🔄 Reset Session", type="secondary", use_container_width=True):
            SessionManager.reset_session()
            st.rerun()
        
        st.divider()
        
        # About
        st.header("ℹ️ About")
        st.markdown("""
        This tool helps you build structured AI prompts through an interactive questionnaire.
        
        **How it works:**
        1. Answer questions one by one
        2. AI generates contextual follow-ups
        3. Your answers build a JSON prompt
        4. Export when complete
        """)
    
    # Main content area
    if not st.session_state.is_complete:
        # Show progress
        col1, col2 = st.columns([3, 1])
        with col1:
            progress_value = SessionManager.get_completeness()
            st.progress(progress_value)
        with col2:
            st.markdown(
                f'<div class="progress-text">{format_progress_text(st.session_state.question_count, settings.max_questions, progress_value)}</div>',
                unsafe_allow_html=True
            )
        
        st.divider()
        
        # Two column layout
        col_left, col_right = st.columns([1, 1])
        
        with col_left:
            # Conversation History
            st.subheader("💬 Conversation History")
            
            if st.session_state.qa_history:
                history_container = st.container(height=400)
                with history_container:
                    for i, qa in enumerate(st.session_state.qa_history):
                        with st.expander(f"Q{i+1}: {qa['question'][:50]}...", expanded=(i == len(st.session_state.qa_history) - 1)):
                            st.markdown(format_qa_display(qa['question'], qa['answer'], i+1))
            else:
                st.info("No questions answered yet. Start by answering the first question!")
            
            st.divider()
            
            # Current Question Section
            st.subheader("❓ Current Question")
            
            # Get or generate current question
            if not st.session_state.current_question:
                if st.session_state.question_count == 0:
                    # First question
                    question_gen = QuestionGenerator()
                    st.session_state.current_question = question_gen.get_initial_question()
                else:
                    # Generate next question
                    st.session_state.is_loading = True
            
            # Display current question
            if st.session_state.current_question:
                st.markdown(f'<div class="question-box"><strong>{st.session_state.current_question}</strong></div>', unsafe_allow_html=True)
                
                # Answer input
                answer = st.text_area(
                    "Your Answer:",
                    value=st.session_state.current_answer,
                    height=100,
                    placeholder="Type your answer here...",
                    key="answer_input"
                )
                
                # Buttons
                btn_col1, btn_col2 = st.columns([3, 1])
                
                with btn_col1:
                    if st.button("✅ Submit Answer", type="primary", use_container_width=True):
                        # Validate answer
                        is_valid, error_msg = validate_answer(answer)
                        
                        if is_valid:
                            # Add to history
                            SessionManager.add_qa_pair(st.session_state.current_question, answer)
                            
                            # Check if should continue
                            question_gen = QuestionGenerator()
                            should_continue = question_gen.should_continue(
                                st.session_state.question_count,
                                SessionManager.get_completeness()
                            )
                            
                            if should_continue:
                                # Clear for next question
                                st.session_state.current_question = ""
                                st.session_state.current_answer = ""
                                st.session_state.is_loading = True
                                st.rerun()
                            else:
                                # Complete the session
                                SessionManager.finalize_prompt()
                                st.rerun()
                        else:
                            st.error(error_msg)
                
                with btn_col2:
                    if settings.enable_skip_questions:
                        if st.button("⏭️ Skip", use_container_width=True):
                            st.session_state.current_question = ""
                            st.session_state.current_answer = ""
                            st.session_state.is_loading = True
                            st.rerun()
            
            # Generate next question if loading
            if st.session_state.is_loading:
                with st.spinner("🤔 Generating next question..."):
                    question_gen = QuestionGenerator()
                    
                    async def get_question():
                        return await question_gen.get_next_question(
                            SessionManager.get_qa_history(),
                            SessionManager.get_current_prompt()
                        )
                    
                    try:
                        next_question = asyncio.run(get_question())
                        st.session_state.current_question = next_question
                        st.session_state.is_loading = False
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error generating question: {str(e)}")
                        st.session_state.is_loading = False
        
        with col_right:
            # Prompt Preview
            st.subheader("📄 Current Prompt Preview")
            
            current_prompt = SessionManager.get_current_prompt()
            
            # Show formatted JSON
            st.json(current_prompt, expanded=False)
            
            # Download button (even if not complete)
            if st.session_state.question_count > 0:
                st.divider()
                st.markdown("**💾 Export Options**")
                
                exporter = Exporter()
                
                col1, col2 = st.columns(2)
                
                with col1:
                    prompt_json = exporter.export_json_prompt(current_prompt)
                    st.download_button(
                        label="⬇️ Prompt JSON",
                        data=prompt_json,
                        file_name=exporter.get_filename("prompt"),
                        mime="application/json",
                        use_container_width=True
                    )
                
                with col2:
                    history_json = exporter.export_conversation_history(SessionManager.get_qa_history())
                    st.download_button(
                        label="⬇️ History",
                        data=history_json,
                        file_name=exporter.get_filename("history"),
                        mime="application/json",
                        use_container_width=True
                    )
                
                combined_json = exporter.export_combined(current_prompt, SessionManager.get_qa_history())
                st.download_button(
                    label="⬇️ Complete Export (Prompt + History)",
                    data=combined_json,
                    file_name=exporter.get_filename("combined"),
                    mime="application/json",
                    use_container_width=True,
                    type="primary"
                )
    
    else:
        # Session Complete
        st.success("🎉 Questionnaire Complete!")
        st.balloons()
        
        final_prompt = SessionManager.get_current_prompt()
        
        # Display summary
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Questions", st.session_state.question_count)
        with col2:
            st.metric("Completeness", f"{int(SessionManager.get_completeness() * 100)}%")
        with col3:
            st.metric("Sections Filled", len([k for k, v in final_prompt.items() if v and k != "metadata"]))
        
        st.divider()
        
        # Show final prompt
        st.subheader("📄 Final Prompt")
        st.json(final_prompt)
        
        st.divider()
        
        # Export options
        st.subheader("💾 Export Your Prompt")
        
        exporter = Exporter()
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            prompt_json = exporter.export_json_prompt(final_prompt)
            st.download_button(
                label="⬇️ Download Prompt JSON",
                data=prompt_json,
                file_name=exporter.get_filename("prompt"),
                mime="application/json",
                use_container_width=True
            )
        
        with col2:
            history_json = exporter.export_conversation_history(SessionManager.get_qa_history())
            st.download_button(
                label="⬇️ Download History",
                data=history_json,
                file_name=exporter.get_filename("history"),
                mime="application/json",
                use_container_width=True
            )
        
        with col3:
            combined_json = exporter.export_combined(final_prompt, SessionManager.get_qa_history())
            st.download_button(
                label="⬇️ Download Complete Export",
                data=combined_json,
                file_name=exporter.get_filename("combined"),
                mime="application/json",
                use_container_width=True,
                type="primary"
            )
        
        st.divider()
        
        # Start new session
        if st.button("🔄 Start New Session", type="secondary", use_container_width=True):
            SessionManager.reset_session()
            st.rerun()


if __name__ == "__main__":
    main()
