# 🤖 AI-Powered Prompt Builder

An interactive Streamlit application that helps non-technical users create structured AI prompts through a conversational questionnaire powered by OpenAI's GPT-4o-mini.

## 🎯 Features

- **Interactive Q&A Interface**: Chat-like experience with dynamic question generation
- **AI-Powered Questions**: Context-aware questions generated based on your previous answers
- **Real-time Prompt Building**: Watch your JSON prompt structure build as you answer
- **Conversation History**: Review all your Q&A pairs in one place
- **Multiple Export Formats**: Download JSON prompt, conversation history, or combined export
- **Progress Tracking**: Visual progress bar and completeness percentage
- **Session Management**: Reset and start new sessions anytime

## 🚀 Quick Start

### Prerequisites

- Python 3.10 or higher
- OpenAI API key (for GPT-4o-mini)

### Installation

1. **Clone or navigate to the project directory**
   ```bash
   cd caf-demo
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and add your OpenAI API key:
   ```env
   OPENAI_API_KEY=your_actual_openai_api_key_here
   ```

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

5. **Open in browser**
   - The app will automatically open at `http://localhost:8501`

## 📖 How to Use

1. **Start the App**: Launch the Streamlit application
2. **Answer Questions**: The AI will ask you contextual questions one at a time
3. **Review History**: See all your previous Q&A pairs in the conversation history panel
4. **Monitor Progress**: Track your progress with the progress bar and completeness percentage
5. **Preview Prompt**: Watch the JSON prompt structure build in real-time
6. **Export Results**: Download your prompt in various formats when ready

### Example Flow

```
Q1: For whom are you building this code or solution?
A1: Sales agent for healthcare industry

Q2: What industry does this target?
A2: Healthcare - specifically hospitals and clinics

Q3: What are the main goals of this sales agent?
A3: Automate lead qualification and schedule demos

... (continues for 10-15 questions)
```

## 🏗️ Project Structure

```
caf-demo/
├── app.py                      # Main Streamlit application
├── requirements.txt            # Python dependencies
├── .env.example               # Environment variables template
├── .gitignore                 # Git ignore file
├── README.md                  # This file
├── src/
│   ├── ai_client.py          # AI API integration
│   ├── question_generator.py # Question generation logic
│   ├── prompt_builder.py     # JSON prompt construction
│   ├── session_manager.py    # Session state management
│   └── exporters.py          # Export functionality
├── config/
│   └── settings.py           # App configuration
├── utils/
│   ├── validators.py         # Input validation
│   └── formatters.py         # Output formatting
└── tests/                    # Unit tests
```

## ⚙️ Configuration

Edit `.env` file to customize:

```env
# AI Provider (openai or deepseek)
AI_PROVIDER=openai
OPENAI_API_KEY=your_openai_key_here
OPENAI_API_URL=https://api.openai.com/v1

# Question Limits
MAX_QUESTIONS=15
MIN_QUESTIONS=10

# Features
ENABLE_SKIP_QUESTIONS=true
ENABLE_EDIT_ANSWERS=false
```

## 📦 Export Formats

### 1. JSON Prompt (`prompt_output_YYYYMMDD_HHMMSS.json`)
Contains the structured prompt ready for AI consumption:
```json
{
  "metadata": {...},
  "target_user": {...},
  "requirements": {...},
  "context": {...}
}
```

### 2. Conversation History (`conversation_history_YYYYMMDD_HHMMSS.json`)
Contains all Q&A pairs:
```json
{
  "exported_at": "...",
  "total_questions": 12,
  "conversation": [...]
}
```

### 3. Complete Export (`complete_export_YYYYMMDD_HHMMSS.json`)
Combines both prompt and conversation history

## 🧪 Testing

Run tests:
```bash
pytest tests/ -v
```

Run with coverage:
```bash
pytest tests/ --cov=src --cov-report=html
```

## 🔧 Troubleshooting

### API Key Issues
- **Error: "API key not configured"**
  - Make sure `.env` file exists and contains `OPENAI_API_KEY`
  - Restart the Streamlit app after adding the key

### Connection Issues
- **Error: "API request failed"**
  - Check your internet connection
  - Verify API key is valid
  - Check API service status

### Question Generation Issues
- **Questions seem repetitive**
  - This can happen with very short answers
  - Try providing more detailed responses

## 📝 Tips for Best Results

1. **Provide detailed answers**: The more context you give, the better the AI can generate relevant follow-up questions
2. **Be specific**: Instead of "sales tool", say "B2B sales automation tool for healthcare"
3. **Review as you go**: Check the prompt preview to see how your answers are being structured
4. **Don't rush**: Take time to think about each answer
5. **Use skip wisely**: Only skip questions that truly don't apply to your use case

## 🛠️ Technology Stack

- **Framework**: Streamlit 1.30+
- **Language**: Python 3.10+
- **AI Provider**: OpenAI GPT-4o-mini (also supports DeepSeek)
- **HTTP Client**: httpx (async support)
- **Validation**: Pydantic

## 📄 License

This project is for demonstration purposes.

## 🤝 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review the `.env.example` for configuration options
3. Ensure all dependencies are installed correctly

## 🚀 Future Enhancements

- [ ] Multi-language support
- [ ] Edit previous answers
- [ ] Save/load sessions
- [ ] User authentication
- [ ] Multiple AI provider support
- [ ] Custom question templates
- [ ] Prompt templates library

---

**Built with ❤️ using Streamlit and OpenAI GPT-4o-mini**
