"""Input Validators"""


def validate_answer(answer: str) -> tuple[bool, str]:
    """Validate user answer input"""
    
    if not answer or not answer.strip():
        return False, "Answer cannot be empty"
    
    if len(answer.strip()) < 2:
        return False, "Answer is too short. Please provide more detail."
    
    if len(answer) > 1000:
        return False, "Answer is too long. Please keep it under 1000 characters."
    
    return True, ""


def validate_api_key(api_key: str) -> tuple[bool, str]:
    """Validate API key format"""
    
    if not api_key or not api_key.strip():
        return False, "API key cannot be empty"
    
    if len(api_key) < 10:
        return False, "API key appears to be invalid (too short)"
    
    return True, ""
