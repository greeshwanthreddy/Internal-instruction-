"""Output Formatters"""
import json
from typing import Dict, Any


def format_json_preview(data: Dict[str, Any], max_depth: int = 3) -> str:
    """Format JSON for preview with limited depth"""
    try:
        return json.dumps(data, indent=2, ensure_ascii=False)
    except Exception:
        return "{}"


def format_progress_text(current: int, total: int, completeness: float) -> str:
    """Format progress text"""
    percentage = int(completeness * 100)
    return f"Question {current}/{total} • {percentage}% Complete"


def format_qa_display(question: str, answer: str, number: int) -> str:
    """Format Q&A pair for display"""
    return f"**Q{number}:** {question}\n\n**A{number}:** {answer}"
