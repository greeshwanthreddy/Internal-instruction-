"""Prompt Builder - Constructs JSON prompt incrementally from Q&A pairs"""
from datetime import datetime
from typing import Dict, Any, List


class PromptBuilder:
    """Builds structured JSON prompt from conversation history"""
    
    def __init__(self):
        self.prompt = self._initialize_prompt()
    
    def _initialize_prompt(self) -> Dict[str, Any]:
        """Initialize empty prompt structure"""
        return {
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "version": "1.0",
                "total_questions": 0
            },
            "target_user": {},
            "requirements": {
                "primary_goal": "",
                "key_features": [],
                "constraints": [],
                "success_criteria": []
            },
            "context": {
                "use_case": "",
                "technical_requirements": {},
                "business_requirements": {}
            },
            "conversation_history": []
        }
    
    def update_prompt(self, qa_pair: Dict[str, str]) -> Dict[str, Any]:
        """Update prompt with new Q&A pair"""
        
        # Add to conversation history
        self.prompt["conversation_history"].append({
            "question_number": len(self.prompt["conversation_history"]) + 1,
            "question": qa_pair["question"],
            "answer": qa_pair["answer"],
            "timestamp": datetime.now().isoformat()
        })
        
        # Update metadata
        self.prompt["metadata"]["total_questions"] = len(self.prompt["conversation_history"])
        
        # Intelligently categorize answer into prompt structure
        self._categorize_answer(qa_pair)
        
        return self.prompt
    
    def _categorize_answer(self, qa_pair: Dict[str, str]):
        """Categorize answer into appropriate prompt section"""
        question = qa_pair["question"].lower()
        answer = qa_pair["answer"]
        
        # Target user detection
        if any(keyword in question for keyword in ["whom", "who", "target", "audience", "user"]):
            if "role" not in self.prompt["target_user"]:
                self.prompt["target_user"]["role"] = answer
        
        # Industry detection
        if "industry" in question or "sector" in question:
            self.prompt["target_user"]["industry"] = answer
        
        # Goal/Purpose detection
        if any(keyword in question for keyword in ["goal", "purpose", "objective", "trying to"]):
            self.prompt["requirements"]["primary_goal"] = answer
        
        # Features detection
        if any(keyword in question for keyword in ["feature", "functionality", "capability", "should do"]):
            if answer not in self.prompt["requirements"]["key_features"]:
                self.prompt["requirements"]["key_features"].append(answer)
        
        # Constraints detection
        if any(keyword in question for keyword in ["constraint", "limitation", "restriction", "cannot"]):
            if answer not in self.prompt["requirements"]["constraints"]:
                self.prompt["requirements"]["constraints"].append(answer)
        
        # Success criteria detection
        if any(keyword in question for keyword in ["success", "measure", "metric", "know if"]):
            if answer not in self.prompt["requirements"]["success_criteria"]:
                self.prompt["requirements"]["success_criteria"].append(answer)
        
        # Use case detection
        if "use case" in question or "scenario" in question:
            self.prompt["context"]["use_case"] = answer
        
        # Technical requirements
        if any(keyword in question for keyword in ["technical", "technology", "platform", "framework"]):
            self.prompt["context"]["technical_requirements"][question] = answer
        
        # Business requirements
        if any(keyword in question for keyword in ["business", "budget", "timeline", "deadline"]):
            self.prompt["context"]["business_requirements"][question] = answer
    
    def get_current_prompt(self) -> Dict[str, Any]:
        """Get current prompt structure"""
        return self.prompt
    
    def calculate_completeness(self) -> float:
        """Calculate how complete the prompt is (0.0 to 1.0)"""
        total_fields = 0
        filled_fields = 0
        
        # Check target_user
        total_fields += 2  # role, industry
        if self.prompt["target_user"].get("role"):
            filled_fields += 1
        if self.prompt["target_user"].get("industry"):
            filled_fields += 1
        
        # Check requirements
        total_fields += 3  # primary_goal, key_features, success_criteria
        if self.prompt["requirements"]["primary_goal"]:
            filled_fields += 1
        if self.prompt["requirements"]["key_features"]:
            filled_fields += 1
        if self.prompt["requirements"]["success_criteria"]:
            filled_fields += 1
        
        # Check context
        total_fields += 1  # use_case
        if self.prompt["context"]["use_case"]:
            filled_fields += 1
        
        return filled_fields / total_fields if total_fields > 0 else 0.0
    
    def finalize_prompt(self) -> Dict[str, Any]:
        """Finalize and return the complete prompt"""
        self.prompt["metadata"]["finalized_at"] = datetime.now().isoformat()
        self.prompt["metadata"]["completeness"] = self.calculate_completeness()
        return self.prompt
    
    def reset(self):
        """Reset prompt to initial state"""
        self.prompt = self._initialize_prompt()
