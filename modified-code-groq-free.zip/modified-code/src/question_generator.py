"""Question Generator - Manages question flow and termination logic"""
from typing import List, Dict, Any
from src.ai_client import AIClient
from config.settings import settings


class QuestionGenerator:
    """Generates and manages the question flow"""
    
    def __init__(self):
        self.ai_client = AIClient()
        self.min_questions = settings.min_questions
        self.max_questions = settings.max_questions
    
    def get_initial_question(self) -> str:
        """Get the first question to start the conversation"""
        return self.ai_client.get_initial_question()
    
    async def get_next_question(
        self, 
        qa_history: List[Dict[str, str]], 
        current_prompt: Dict[str, Any]
    ) -> str:
        """Generate next contextual question based on history"""
        return await self.ai_client.generate_question(qa_history, current_prompt)
    
    def should_continue(
        self, 
        question_count: int, 
        completeness: float
    ) -> bool:
        """Determine if we should ask more questions"""
        
        # Must ask at least minimum questions
        if question_count < self.min_questions:
            return True
        
        # Stop if we've reached max questions
        if question_count >= self.max_questions:
            return False
        
        # Stop if prompt is sufficiently complete (>80%) and we've asked min questions
        if completeness >= 0.8 and question_count >= self.min_questions:
            return False
        
        # Otherwise continue
        return True
    
    async def validate_api_connection(self) -> bool:
        """Validate API connection"""
        return await self.ai_client.validate_api_key()
