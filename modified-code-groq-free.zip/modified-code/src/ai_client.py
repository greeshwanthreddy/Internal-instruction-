"""AI API Client for generating questions and processing responses"""
import httpx
import asyncio
from typing import Optional, Dict, Any, List
from config.settings import settings


class AIClientError(Exception):
    """Custom exception for AI client errors"""
    pass


class AIClient:
    """Client for interacting with Groq's free API with Mixtral-8x7b"""
    
    def __init__(self):
        # Use Groq's free API
        self.api_key = settings.groq_api_key
        self.api_url = "https://api.groq.com/openai/v1"
        self.model = settings.model_name
        self.temperature = settings.temperature
        self.max_tokens = settings.max_tokens
        self.timeout = 30.0
        self.max_retries = 3
        
    async def _make_request(
        self, 
        messages: List[Dict[str, str]], 
        retry_count: int = 0
    ) -> Dict[str, Any]:
        """Make API request with retry logic"""
        
        if not self.api_key:
            raise AIClientError(f"API key not configured. Please set GROQ_API_KEY in .env file")
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens
        }
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.api_url}/chat/completions",
                    headers=headers,
                    json=payload
                )
                response.raise_for_status()
                return response.json()
                
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429 and retry_count < self.max_retries:
                # Rate limit - exponential backoff
                wait_time = 2 ** retry_count
                await asyncio.sleep(wait_time)
                return await self._make_request(messages, retry_count + 1)
            elif e.response.status_code == 401:
                raise AIClientError(f"Invalid API key. Please check your GROQ_API_KEY")
            else:
                raise AIClientError(f"API request failed: {e.response.status_code} - {e.response.text}")
                
        except httpx.TimeoutException:
            if retry_count < self.max_retries:
                return await self._make_request(messages, retry_count + 1)
            raise AIClientError("API request timed out after multiple retries")
            
        except Exception as e:
            raise AIClientError(f"Unexpected error: {str(e)}")
    
    async def generate_question(
        self, 
        qa_history: List[Dict[str, str]], 
        current_prompt: Dict[str, Any]
    ) -> str:
        """Generate next contextual question based on conversation history"""
        
        # Build context from Q&A history
        conversation_context = "\n".join([
            f"Q{i+1}: {qa['question']}\nA{i+1}: {qa['answer']}"
            for i, qa in enumerate(qa_history)
        ])
        
        # System prompt for question generation
        system_prompt = """You are a prompt engineering assistant. Your job is to ask ONE clarifying question at a time to build a comprehensive AI prompt.

Your questions should:
1. Build on previous answers naturally
2. Fill gaps in understanding the user's needs
3. Be specific and actionable
4. Help define exact requirements
5. Cover aspects like: target audience, goals, constraints, features, technical requirements, success criteria

Return ONLY the question text, nothing else. No explanations, no preambles."""

        user_prompt = f"""Current conversation:
{conversation_context if conversation_context else "No previous questions yet."}

Current prompt structure being built:
{current_prompt}

Generate the next most important question to ask. This is question #{len(qa_history) + 1}."""

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        response = await self._make_request(messages)
        
        try:
            question = response["choices"][0]["message"]["content"].strip()
            return question
        except (KeyError, IndexError) as e:
            raise AIClientError(f"Invalid API response format: {str(e)}")
    
    async def validate_api_key(self) -> bool:
        """Validate that the API key is working"""
        try:
            messages = [{"role": "user", "content": "Hi"}]
            await self._make_request(messages)
            return True
        except AIClientError:
            return False
    
    def get_initial_question(self) -> str:
        """Return the first question to start the conversation"""
        return "For whom are you building this code or solution? (e.g., sales agent, customer support, data analyst)"
