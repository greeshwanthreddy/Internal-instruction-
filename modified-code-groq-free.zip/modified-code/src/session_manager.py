"""Session Manager - Manages Streamlit session state"""
import streamlit as st
from typing import Dict, List, Any
from src.prompt_builder import PromptBuilder


class SessionManager:
    """Manages session state for the Streamlit app"""
    
    @staticmethod
    def initialize_session():
        """Initialize session state variables"""
        if "qa_history" not in st.session_state:
            st.session_state.qa_history = []
        
        if "current_question" not in st.session_state:
            st.session_state.current_question = ""
        
        if "prompt_builder" not in st.session_state:
            st.session_state.prompt_builder = PromptBuilder()
        
        if "question_count" not in st.session_state:
            st.session_state.question_count = 0
        
        if "is_complete" not in st.session_state:
            st.session_state.is_complete = False
        
        if "current_answer" not in st.session_state:
            st.session_state.current_answer = ""
        
        if "is_loading" not in st.session_state:
            st.session_state.is_loading = False
    
    @staticmethod
    def add_qa_pair(question: str, answer: str):
        """Add a Q&A pair to history and update prompt"""
        qa_pair = {
            "question": question,
            "answer": answer
        }
        
        st.session_state.qa_history.append(qa_pair)
        st.session_state.prompt_builder.update_prompt(qa_pair)
        st.session_state.question_count += 1
    
    @staticmethod
    def get_qa_history() -> List[Dict[str, str]]:
        """Get conversation history"""
        return st.session_state.qa_history
    
    @staticmethod
    def get_current_prompt() -> Dict[str, Any]:
        """Get current prompt structure"""
        return st.session_state.prompt_builder.get_current_prompt()
    
    @staticmethod
    def get_completeness() -> float:
        """Get prompt completeness score"""
        return st.session_state.prompt_builder.calculate_completeness()
    
    @staticmethod
    def finalize_prompt() -> Dict[str, Any]:
        """Finalize the prompt"""
        st.session_state.is_complete = True
        return st.session_state.prompt_builder.finalize_prompt()
    
    @staticmethod
    def reset_session():
        """Reset session to initial state"""
        st.session_state.qa_history = []
        st.session_state.current_question = ""
        st.session_state.prompt_builder = PromptBuilder()
        st.session_state.question_count = 0
        st.session_state.is_complete = False
        st.session_state.current_answer = ""
        st.session_state.is_loading = False
