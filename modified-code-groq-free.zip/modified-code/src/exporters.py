"""Export Handler - Exports data in various formats"""
import json
from typing import Dict, Any, List
from datetime import datetime


class Exporter:
    """Handles exporting data to various formats"""
    
    @staticmethod
    def export_json_prompt(prompt: Dict[str, Any]) -> str:
        """Export JSON prompt as formatted string"""
        return json.dumps(prompt, indent=2, ensure_ascii=False)
    
    @staticmethod
    def export_conversation_history(qa_history: List[Dict[str, str]]) -> str:
        """Export conversation history as formatted JSON"""
        history_data = {
            "exported_at": datetime.now().isoformat(),
            "total_questions": len(qa_history),
            "conversation": qa_history
        }
        return json.dumps(history_data, indent=2, ensure_ascii=False)
    
    @staticmethod
    def export_combined(prompt: Dict[str, Any], qa_history: List[Dict[str, str]]) -> str:
        """Export combined prompt and conversation history"""
        combined_data = {
            "exported_at": datetime.now().isoformat(),
            "prompt": prompt,
            "conversation_history": qa_history
        }
        return json.dumps(combined_data, indent=2, ensure_ascii=False)
    
    @staticmethod
    def get_filename(export_type: str) -> str:
        """Generate filename with timestamp"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        filenames = {
            "prompt": f"prompt_output_{timestamp}.json",
            "history": f"conversation_history_{timestamp}.json",
            "combined": f"complete_export_{timestamp}.json"
        }
        
        return filenames.get(export_type, f"export_{timestamp}.json")
