"""Application Settings and Configuration"""
from pydantic_settings import BaseSettings
from typing import Literal


class Settings(BaseSettings):
    """Application configuration loaded from environment variables"""
    
    # AI API Configuration - Using Groq Free API (no payment needed!)
    groq_api_key: str = ""
    
    # App Configuration
    max_questions: int = 15
    min_questions: int = 10
    session_timeout: int = 3600
    
    # Feature Flags
    enable_skip_questions: bool = True
    enable_edit_answers: bool = False
    
    # AI Model Configuration
    # Using Mixtral-8x7b (free and fast on Groq)
    model_name: str = "mixtral-8x7b-32768"
    temperature: float = 0.7
    max_tokens: int = 500
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Global settings instance
settings = Settings()
